tupla_anidada = ((1, 2, 3), (4, 5, 6), (7, 8, 9))
numero_5 = tupla_anidada[1][1]
print(numero_5)  
