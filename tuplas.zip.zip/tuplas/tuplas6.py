nombres = ['Ana', 'Juan', 'Pedro', 'Luis']
tupla_nombres = tuple(nombres)
print(tupla_nombres)
