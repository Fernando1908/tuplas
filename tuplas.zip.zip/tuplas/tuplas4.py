tupla_pares = (2, 4, 6, 8, 10)
tupla_impares = (1, 3, 5, 7, 9)
tupla_concatenada = tupla_pares + tupla_impares
print(tupla_concatenada)
