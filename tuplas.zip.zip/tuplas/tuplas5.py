colores = ('rojo', 'azul', 'verde', 'rojo', 'amarillo', 'rojo')
conteo_rojo = colores.count('rojo')
print(conteo_rojo)  
