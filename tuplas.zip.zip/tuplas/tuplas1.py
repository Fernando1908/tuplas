def crear_tupla(num1, num2, num3):
    return (num1, num2, num3)


resultado = crear_tupla(10, 20, 30)
print(resultado) 
