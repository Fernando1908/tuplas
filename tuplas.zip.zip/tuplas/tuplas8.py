a = 5
b = 10
a, b = b, a
print("a =", a)  
print("b =", b)  
